﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace buoi3.Models
{
    public partial class Nhanvien
    {
        public Nhanvien()
        {
            Phieugiaohang = new HashSet<Phieugiaohang>();
        }

        public string Manv { get; set; }
        public string Tennv { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode =true)]
        public DateTime? Ngaysinh { get; set; }
        public bool? Phai { get; set; }
        public string Diachi { get; set; }
        public string Password { get; set; }

        public ICollection<Phieugiaohang> Phieugiaohang { get; set; }
    }
}
