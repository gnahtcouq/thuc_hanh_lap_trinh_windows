﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using buoi3.Models;
using Microsoft.AspNetCore.Mvc;

namespace buoi3.Controllers
{
    public class NhanvienController : Controller
    {
        QLBHContext db = new QLBHContext();

        public IActionResult Index()
        {
            ViewBag.Nhanvien = db.Nhanvien;
            return View();
        }

        [HttpGet]
        public ActionResult them()
        {
            return View();
        }
        [HttpPost]
        public ActionResult them(Nhanvien n)
        {
            db.Nhanvien.Add(n);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult sua(string id)
        {
            Nhanvien nv = db.Nhanvien.Find(id);
            ViewBag.nv = nv;
            return View(nv);
        }
        public ActionResult sua(Nhanvien n)
        {
            Nhanvien nv = db.Nhanvien.Find(n.Manv);
            nv.Tennv = n.Tennv;
            nv.Ngaysinh = n.Ngaysinh;
            nv.Phai = n.Phai;
            nv.Diachi = n.Diachi;
            nv.Password = n.Password;
            db.SaveChanges();
            return RedirectToAction("index");
        }
        [HttpGet]
        public ActionResult xoa(string id)
        {
            Nhanvien n = db.Nhanvien.Find(id);
            ViewBag.nv = n;
            return View(n);
        }
        [HttpPost, ActionName("xoa")]
        public ActionResult xoa_Post(string id)
        {
            Nhanvien n = db.Nhanvien.Find(id);
            if (n != null)
            {
                db.Nhanvien.Remove(n);
                db.SaveChanges();
            }
            return RedirectToAction("index");
        }
    }
}