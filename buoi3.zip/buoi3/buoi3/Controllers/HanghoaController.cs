﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using buoi3.Models;

namespace buoi3.Controllers
{
    public class HanghoaController : Controller
    {
        QLBHContext db = new QLBHContext();

        public IActionResult Index()
        {
            ViewBag.Hanghoa = db.Hanghoa;
            return View();
        }

        [HttpGet]
        public ActionResult themHH()
        {
            return View();
        }
        [HttpPost]
        public ActionResult themHH(Hanghoa n)
        {
            db.Hanghoa.Add(n);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}