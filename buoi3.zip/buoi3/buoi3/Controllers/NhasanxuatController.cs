﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using buoi3.Models;

namespace buoi3.Controllers
{
    public class NhasanxuatController : Controller
    {
        QLBHContext db = new QLBHContext();

        public IActionResult Index()
        {
            ViewBag.Nhasanxuat = db.Nhasanxuat;
            return View();
        }

        [HttpGet]
        public ActionResult themNSX()
        {
            return View();
        }
        [HttpPost]
        public ActionResult themNSX(Nhasanxuat n)
        {
            db.Nhasanxuat.Add(n);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}