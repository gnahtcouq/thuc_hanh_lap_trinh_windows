using System;

namespace TranVanQuocThang_DH52007101_D20_TH11.Models {
    public class ErrorViewModel {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}