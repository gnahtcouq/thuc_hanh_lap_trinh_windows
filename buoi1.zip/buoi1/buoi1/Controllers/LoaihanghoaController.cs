﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using buoi1.Models;

namespace buoi1.Controllers
{
    public class LoaihanghoaController : Controller
    {
        QLBHContext db = new QLBHContext();

        public IActionResult Index()
        {
            ViewBag.Loaihanghoa = db.Loaihanghoa;
            return View();
        }

        [HttpGet]
        public ActionResult themLH()
        {
            return View();
        }
        [HttpPost]
        public ActionResult themLH(Loaihanghoa n)
        {
            db.Loaihanghoa.Add(n);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}