﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DH52007101.Models {
    public class IndexModel {
        public string Message { get; set; }
    }
}
