﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DH52007101.Models;
using Microsoft.AspNetCore.Mvc;

namespace DH52007101.Controllers {
    public class LoaihanghoaController : Controller {
        QLBHContext db = new QLBHContext();
        public IActionResult Index() {
            ViewBag.lhh = db.Loaihanghoa;
            return View();
        }

        // Thêm
        [HttpGet]
        public ActionResult them() {
            return View();
        }
        [HttpPost]
        public ActionResult them(Loaihanghoa n) {
            db.Loaihanghoa.Add(n);
            db.SaveChanges();
            return RedirectToAction("index");
        }
    }
}